setwd("~/MyPackages/dir2json/inst/js")

library(magrittr)
library(V8)


ct <- v8()
ct$source("jsondirtree.js")

#ct$assign("wb", wb)

ct$eval('
jsontree = {
	"name": "D0",
	"_type": "folder",
	"children": [
		{
			"name": "D00",
			"_type": "folder",
			"children": [
				{
					"name": "file000.txt",
					"_type": "file",
					"size": 100
				},
				{
					"name": "file001.txt",
					"_type": "file",
					"size": 42
				}
			]
		},
		{
			"name": "file01.R",
			"_type": "file",
			"size": 99
		}
	]
}
') %>% invisible


# D3 diagonal network -----------------------------------------------------
library(networkD3)
jsontree <- ct$get("JSON.stringify(jsontree)") %>%
  jsonlite::fromJSON(simplifyDataFrame = FALSE)
diagonalNetwork(List=jsontree)


# get all file extensions -------------------------------------------------
ct$eval('
var extensions = getFileExtensions(jsontree)
')

ct$get('
JSON.stringify(extensions)
') %>% cat


# get all names in the tree -----------------------------------------------
ct$eval('
var allNames = getAllNames(jsontree)
')
ct$get('
JSON.stringify(allNames, null, "  ")
') %>% cat



# get path(s) to a node ----------------------------------------------------
ct$eval('
var thefile = searchTree(jsontree, "file000.txt", [])
')

ct$get('
JSON.stringify(thefile, null, "  ")
') %>% cat


