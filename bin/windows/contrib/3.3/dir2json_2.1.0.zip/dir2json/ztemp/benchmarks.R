library(dir2json)
dirTree <- function(root){
  bname <- basename(root)
  out <- list(name=bname)
  infos <- file.info(root)
  isdir <- infos$isdir
  if(isdir){
    out[["_type"]] <- "folder"
    childs <- list.files(root, include.dirs=TRUE, full.names=TRUE)
    out$children <- lapply(childs, dirTree)
  }else{
    out[["_type"]] <- "file"
    out$size <- infos$size
  }
  return(out)
}

# R:
system.time(x <- dirTree("."))
# Haskell:
system.time(x <- dir2json("."))
# R:
system.time(x <- dirTree(".."))
# Haskell:
system.time(x <- dir2json(".."))
