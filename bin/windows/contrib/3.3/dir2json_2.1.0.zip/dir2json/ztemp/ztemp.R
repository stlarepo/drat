dll <- dyn.load("inst/libs/x64/JsonDirTreeR.dll")
.C("HsStart")
source("R/jsondirtree.R")

dir2json(normalizePath("."), 1)
