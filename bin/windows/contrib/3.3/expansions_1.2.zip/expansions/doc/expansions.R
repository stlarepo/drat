## ------------------------------------------------------------------------
library(expansions)

## ------------------------------------------------------------------------
intAtBase(32, base=3)

## ------------------------------------------------------------------------
2*1 + 1*3 + 0*3^2 + 1*3^3

## ------------------------------------------------------------------------
intAtBasePower(2, 5, base=3)
intAtBase(2^5, base=3)

## ---- error=TRUE---------------------------------------------------------
# 2^100 is too big for intAtBase:
intAtBase(2^100, base=3)
# then use intAtBasePower:
( digits <- intAtBasePower(2, 100, base=3) )
sum(digits * 3^(seq_along(digits)-1)) == 2^100

## ------------------------------------------------------------------------
intAtBaseFib(6, base=3)
intAtBase(8, base=3)

## ------------------------------------------------------------------------
digits <- intAtBaseFib(50, base=3)
sum(digits * 3^(seq_along(digits)-1))

## ------------------------------------------------------------------------
intToAry(34, sizes=c(3,4,7))

## ------------------------------------------------------------------------
1*1 + 3*3 + 2*(3*4)

## ---- error=TRUE---------------------------------------------------------
intToAry(83, sizes=c(3,4,7))
intToAry(84, sizes=c(3,4,7))

## ------------------------------------------------------------------------
# Cartesian product {0,1,2}x{0,1,2,3}:
sapply(0:11, function(x) intToAry(x, sizes=c(3,4)))
t(expand.grid(c(0,1,2), c(0,1,2,3)))

## ------------------------------------------------------------------------
floatExpand01(0.625, base=2)

## ------------------------------------------------------------------------
floatExpand(1.125, base=2)
# check:
1.125 == (1*1/2 + 0*1/2^2 + 0*1/2^3 + 1*1/2^4) * 2^1

## ------------------------------------------------------------------------
odometer(c(1,0,1), base=2)

## ----odometer, fig.width=5, fig.height=5, fig.align='center', fig.show='hold'----
ternary2num <- function(t) sum(t/3^seq_along(t))
num2ternary <- function(u) floatExpand01(u, base=3)
par(mar=c(4,4,2,2))
u <- seq(0, 0.995, by=0.0025)
Ou <- sapply(u, function(u) ternary2num(odometer(num2ternary(u), base=3)))
plot(u, Ou, xlab="u", ylab="O(u)", xlim=c(0,1), ylim=c(0,1),
     pch=19, cex=.25, pty="s", xaxs="i", yaxs="i")
grid(nx=9)

## ------------------------------------------------------------------------
sumadic(c(0,1), c(1,1,1), base=2)
identical(sumadic(c(0,1), 1, base=2), odometer(c(0,1), base=2))

## ------------------------------------------------------------------------
d <- c(1,0,2)
b <- 3
identical(odometer(odometer(d, base=b), base=b), odometer_iterated(d, n=2, base=b))

## ------------------------------------------------------------------------
n <- 13
odometer_iterated(d, n=n, base=b)
sumadic(d, intAtBase(n, base=b), base=b)

## ------------------------------------------------------------------------
n <- 2000000
system.time(odometer_iterated(d, n=n, base=b))
system.time(sumadic(d, intAtBase(n, base=b), base=b))

