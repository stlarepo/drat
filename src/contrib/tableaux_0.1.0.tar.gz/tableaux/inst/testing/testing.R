dll <- "C:/HaskellProjects/tableaux/tableaux.dll"
dyn.load(dll)
.C("HsStart")

shape <- c(3L, 2L)
.C("hookLengthsR", partition=shape, l=length(shape), result=list(0L))$result[[1L]]

dyn.unload(dll)
