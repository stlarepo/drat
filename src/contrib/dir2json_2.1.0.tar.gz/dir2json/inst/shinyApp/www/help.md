***Zoom in:*** double-click - ***Zoom out:*** shift-double-click - ***Translate:*** click and drag
