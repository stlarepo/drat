## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(magrittr)
library(jsonlite)
library(networkD3)
library(V8)
ct <- v8()
ct$source(system.file("shinyApp", "www", "jsondirtree.js", package="dir2json"))

## ----include=FALSE-------------------------------------------------------
ct$eval('
jsontree = {
	"name": "D0",
	"_type": "folder",
	"children": [
		{
			"name": "D00",
			"_type": "folder",
			"children": [
				{
					"name": "file000.txt",
					"_type": "file",
					"size": 100
				},
				{
					"name": "file001.txt",
					"_type": "file",
					"size": 42
				}
			]
		},
		{
			"name": "file01.R",
			"_type": "file",
			"size": 99
		}
	]
}
')

## ---- echo=FALSE---------------------------------------------------------
jsontree <- ct$get("JSON.stringify(jsontree)") %>%
  fromJSON(simplifyDataFrame = FALSE)
diagonalNetwork(List=jsontree, fontSize=12, opacity=0.95)

