library(testthat)
library(dir2json)

test_check("dir2json")
