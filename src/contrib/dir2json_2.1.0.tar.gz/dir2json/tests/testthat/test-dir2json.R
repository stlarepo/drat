context("dir2json")

# faire un check username !

test_that("dir2json tests", {

})
