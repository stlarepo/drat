# dir2json, an R package

Hierarchical JSON representation of a directory, and a Shiny application. 
Also provides a function to get the tree view of a directory.

This packages uses the DLL created by the Haskell libraries [jsondirtree](https://github.com/stla/jsondirtree) and [jsondirtreeR](https://github.com/stla/jsondirtreeR).
