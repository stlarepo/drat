library(testthat)
library(expansions)

test_check("expansions")
